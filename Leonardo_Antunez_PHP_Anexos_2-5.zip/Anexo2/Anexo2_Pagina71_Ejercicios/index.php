<?php require_once "funlib.php" ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 2. Ejercicios página 72</title>
    <style>
        td,th{
            border: 1px solid #000;
            padding: 10px;
        }
        table{
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 1</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php println("Valor de ejemplo") ?>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 2</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php echo aleatorio(100, 1000) ?>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 3</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php echo dia(); ?> / <?php echo mes(); ?>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 4</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php echo operaciones(rand(1,100), rand(1,100), rand(1,4)); ?>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 5</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php 
                    $suma = 0;
                    for ($i=0; $i < 10; $i++) { 
                        $suma+=sumatorio(rand(5,100));
                    } ?>
                    <?php echo $suma; ?>
                </td>
            </tr>
        </tbody>
    </table>


    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 6</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php 
                        $operando1 = rand(2, 10);
                        $operando2 = rand(2, 10);
                    ?>
                    <p>Producto iterativo: <?php echo producto_iterativo($operando1, $operando2); ?></p>
                    <p>Producto recursivo: <?php echo producto_recursivo($operando1, $operando2); ?></p>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 7</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php 
                        $edad = rand(10, 100);
                    ?>
                    <p>Edad <?php echo $edad; ?> es <?php echo validarEdad($edad) ? "válida" : "inválida"; ?></p>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 8</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    Valores incluidos: 
                    <?php 
                    $valores = [];
                    for ($i=0; $i < 10; $i++) { 
                        $valor = rand(5,100);
                        echo "$valor, ";
                        $valores[] = $valor;
                    } ?>
                    <p>
                        <?php $media = media(...$valores); ?>
                        <strong>La media es <?php echo $media; ?></strong>
                    </p>
                </td>
            </tr>
        </tbody>
    </table>

    <table width="300px">
        <thead>
            <tr><th>EJERCICIO 9</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <?php 
                        $hora = rand(0, 23 );
                        $minutos = rand(0, 59);
                    ?>
                    <p>Son las: <?php echo tiempo($hora, $minutos) ?></p>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>