<?php 
    date_default_timezone_set("Europe/Madrid");

    function println($valor){
        print("$valor<br/>");
    }

    function aleatorio($min, $max){
        return rand($min, $max);
    }

    function dia(){
        return date("l");
    }

    function mes(){
        return date("F");
    }

    function operaciones($v1, $v2, $oper){
        switch($oper){
            case 1:
                return $v1+$v2;
            case 2:
                return $v1-$v2;
            case 3:
                return $v1*$v2;
            case 4:
                return round($v1/$v2, 2);
            default:
                return $v1+$v2;
        }
    }

    $sumatoria = 0;
    function sumatorio($valor){
        $sumatoria += $valor;
        return $sumatoria;
    }   

    function producto_iterativo($v1, $v2){
        $i = 1;
        $producto = 0;
        while($i <= $v2){
            $producto += $v1;
            $i++;
        }

        return $producto;
    }

    function producto_recursivo($v1, $v2){
        if ($v2 == 1){
            return $v1;
        }

        return $v1 + producto_recursivo($v1, ($v2 - 1));
        
    }

    function validarEdad($edad){
        return is_int($edad) && $edad >= 18 && $edad <= 65;
    }

    
    function media(...$valores){
        $sumatoriaMedia = 0;
        $elementosMedia = 0;

        foreach ($valores as $valor){
            $sumatoriaMedia += $valor;
            $elementosMedia++;
        }
        
        return round($sumatoriaMedia/$elementosMedia, 2);
    }

    function tiempo($hora, $minuto){
        $minuto++;
        if ($minuto == 60){
            $hora++;
            $minuto = 0;
            if ($hora == 24){
                $hora = 0;
            }
        }
        $hora = str_pad($hora, 2, "0", STR_PAD_LEFT);
        $minuto = str_pad($minuto, 2, "0", STR_PAD_LEFT);
        return "{$hora}:{$minuto}";
    }
?>