<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 1. Página 22. Ejercicio 4</title>

</head>
<body>
    <table>
        <tr>
            <?php for ($i = 0; $i <= 100; $i+=10): ?>
                <?php 
                    $color = '';
                    if ($i <= 20){
                        $color = 'blue';
                    } elseif ($i > 20 && $i <= 60){
                        $color = 'green';
                    }  elseif ($i > 60 && $i <=80){
                        $color = 'yellow';
                    }  elseif ($i > 80 && $i <= 90){
                        $color = 'orange';
                    }  elseif ($i > 90 && $i <= 100){
                        $color = 'red';
                    } 
                ?>
                <td style="color: <?php echo $color; ?>"><?php echo $i; ?></td>           
            <?php endfor;?>
        </tr>
    </table>
</body>
</html>