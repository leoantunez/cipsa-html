<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 1. Página 22. Ejercicio 2</title>
</head>
<body>
    <?php $suma = 0; ?>
    <?php for($i=1; $i<=100;$i++) {
        $suma = $suma + $i;
    } ?>
    <p>La suma de los primeros 100 números naturales es: <?php echo $suma; ?></p>


    <?php $suma = 0; ?>
    <?php $i = 0; ?>
    <?php while($i<=100) {
        $suma = $suma + $i; 
        $i++;
    } ?>
    <p>La suma de los primeros 100 números naturales es: <?php echo $suma; ?></p>


    <?php $suma = 0; ?>
    <?php $i = 1; ?>
    <?php do {
            $suma = $suma + $i; 
            $i++;
    } while($i <= 100) ?>
    <p>La suma de los primeros 100 números naturales es: <?php echo $suma; ?></p>
</body>
</html>