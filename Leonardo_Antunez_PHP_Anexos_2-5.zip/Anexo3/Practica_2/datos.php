<?php
include 'alumnos.php';
$vista = "";
if (isset($_GET['alumno']) && $_GET['alumno']) {
    $asignatura = isset($_GET['asignatura']) ? $_GET['asignatura'] : null;
    $alumno = buscarAlumno($alumnos, $_GET['alumno']);
    if (!$alumno) {
        echo "El alumno no existe";
        exit;
    }
    $datos = buscarCalificacionesAlumno($calificaciones, $asignaturas, $_GET['alumno'], $asignatura);
    include 'calificaciones_alumno.php';
} elseif (isset($_GET['busqueda']) && $_GET['busqueda']) {
    $datos = buscarAlumnos($alumnos, $_GET['busqueda']);
    include 'listado_alumnos.php';
} elseif (isset($_GET['suspensos']) && $_GET['suspensos']) {
    if (!array_key_exists(strtoupper($_GET['suspensos']), $asignaturas)) {
        echo "La asignatura no existe";
        exit;
    }
    $datos = buscarAlumnosSuspensos($calificaciones, $alumnos, $_GET['suspensos']);
    $asignatura = $asignaturas[strtoupper($_GET['suspensos'])];
    include 'listado_alumnos_suspensos.php';
} elseif (isset($_GET['aprobados']) && $_GET['aprobados'] && isset($_GET['convocatoria']) && $_GET['convocatoria']) {
    if (!array_key_exists(strtoupper($_GET['aprobados']), $asignaturas)) {
        echo "La asignatura no existe";
        exit;
    }
    $porcentageAprobados = calcularAprobados($calificaciones, $_GET['aprobados'], $_GET['convocatoria']);
    $asignatura = $asignaturas[strtoupper($_GET['aprobados'])];
    $convocatoria = $_GET['convocatoria'];
    include 'listado_aprobados.php';
} else {
    echo "Opción no permitida";
}


function buscarCalificacionesAlumno($calificaciones, $asignaturas, $cuenta, $asignatura)
{
    $resultadosAsignaturas = array_filter($calificaciones, function ($calificacion) use ($cuenta, $asignatura) {
        if ($asignatura) {
            return $calificacion['asignatura'] === $asignatura && $calificacion['cuenta'] === $cuenta;
        }
        return $calificacion['cuenta'] === $cuenta;
    });

    $datos = [];
    foreach ($resultadosAsignaturas as $resultadosAsignatura) {
        $datos[$asignaturas[$resultadosAsignatura['asignatura']]][] = $resultadosAsignatura;
    }

    return $datos;
}

function buscarAlumno($alumnos, $cuenta)
{
    foreach ($alumnos as $alumno) {
        if ($alumno['cuenta'] === $cuenta) {
            return $alumno;
        }
    }
    return null;
}

function buscarAlumnos($alumnos, $busqueda)
{
    $coincidencias = [];
    foreach ($alumnos as $alumno) {
        if (str_starts_with(strtolower($alumno['nombre']), strtolower($busqueda))) {
            $coincidencias[] = $alumno;
        }
    }
    return $coincidencias;
}

function buscarAlumnosSuspensos($calificaciones, $alumnos, $asignatura)
{
    $suspensos = [];
    foreach ($calificaciones as $calificacion) {
        if (strcasecmp($calificacion['asignatura'], $asignatura) == 0 && $calificacion['convocatoria'] == 6 && $calificacion['calificacion'] < 5) {
            $suspensos[] = [
                'alumno' => buscarAlumno($alumnos, $calificacion['cuenta']),
                'calificacion' => $calificacion['calificacion']
            ];
        }
    }
    return $suspensos;
}

function calcularAprobados($calificaciones, $asignatura, $convocatoria)
{
    $aprobados = 0;
    $totalConvocados = [];
    foreach ($calificaciones as $calificacion) {
        if (strcasecmp($calificacion['asignatura'], $asignatura) == 0 && $calificacion['convocatoria'] <= intval($convocatoria)) {
            $totalConvocados[] = $calificacion['cuenta'];
            if ($calificacion['calificacion'] >= 5) {
                $aprobados++;
            }
        }
    }
    $totalConvocados = count(array_unique($totalConvocados));
    return round($aprobados / $totalConvocados, 2) * 100;
}

