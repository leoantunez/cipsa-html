<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 2 Anexo 3</title>
    <style>
        table {
            margin-bottom: 20px;
        }
        th,td{
            border: 1px solid #333;
            padding: 5px;
        }
    </style>
</head>
<body>
<table>
    <thead>
    <tr>
        <th colspan="2"><?php echo $asignatura; ?></th>

    </tr>
    <tr>
        <th>Convocatoria</th>
        <th>Porcentage de aprobados</th>
    </tr>
    </thead>

    <tr>
        <td><?php echo $convocatoria; ?></td>
        <td><?php echo $porcentageAprobados; ?>%</td>
    </tr>
</table>

</body>
</html>