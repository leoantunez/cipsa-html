<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 2 Anexo 3</title>
    <style>
        table {
            margin-bottom: 20px;
        }
        th,td{
            border: 1px solid #333;
            padding: 5px;
        }
    </style>
</head>
<body>
<table>
    <thead>
    <tr>
        <th colspan="4"><?php echo $asignatura; ?></th>
    </tr>
    <tr>
        <th>Nombre</th>
        <th>Primer apellido</th>
        <th>Segundo apellido</th>
        <th>Calificación última convocatoria</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($datos as $alumno): ?>
        <tr>
            <td><?php echo $alumno['alumno']['nombre']; ?></td>
            <td><?php echo $alumno['alumno']['apellido1']; ?></td>
            <td><?php echo $alumno['alumno']['apellido2']; ?></td>
            <td><?php echo $alumno['calificacion']; ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>