<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 2 Anexo 3</title>
    <style>
        table {
           margin-bottom: 20px;
        }
        th,td{
            border: 1px solid #333;
            padding: 5px;
        }
    </style>
</head>
<body>
<table>
    <thead>
    <tr>
        <th>Nombre</th>
        <th>Primer apellido</th>
        <th>Segundo apellido</th>
        <th>Cuenta</th>
    </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo $alumno['nombre']; ?></td>
            <td><?php echo $alumno['apellido1']; ?></td>
            <td><?php echo $alumno['apellido2']; ?></td>
            <td><?php echo $alumno['cuenta']; ?></td>
        </tr>
    </tbody>
</table>

<?php foreach ($datos as $nombreAsignatura => $asignatura): ?>
    <table>
        <thead>
            <tr>
                <th colspan="2"><?php echo $nombreAsignatura ?></th>
            </tr>
            <tr>
                <th>Convocatoria</th>
                <th>Calificación</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($asignatura as $resultado): ?>
                <tr>
                    <td><?php echo $resultado['convocatoria']; ?></td>
                    <td><?php echo $resultado['calificacion']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endforeach; ?>
</body>
</html>