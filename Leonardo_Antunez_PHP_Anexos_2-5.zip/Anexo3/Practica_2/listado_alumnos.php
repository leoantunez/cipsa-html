<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 2 Anexo 3</title>
    <style>
        table {
           margin-bottom: 20px;
        }
        th,td{
            border: 1px solid #333;
            padding: 5px;
        }
    </style>
</head>
<body>
<table>
    <thead>
    <tr>
        <th>Nombre</th>
        <th>Primer apellido</th>
        <th>Segundo apellido</th>
        <th>Cuenta</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($datos as $alumno): ?>
        <tr>
            <td><?php echo $alumno['nombre']; ?></td>
            <td><?php echo $alumno['apellido1']; ?></td>
            <td><?php echo $alumno['apellido2']; ?></td>
            <td><a href="datos.php?alumno=<?php echo $alumno['cuenta'] ?>"><?php echo $alumno['cuenta']; ?></a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>