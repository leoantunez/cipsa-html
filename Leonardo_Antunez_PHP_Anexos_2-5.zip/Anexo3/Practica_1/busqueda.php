<?php
include 'alumnos.php';
$resultados = [];
switch ($_GET['accion']){
    case 'buscar':
        $resultados = buscarRegistros($alumnos, $_GET['filtro'], strtolower($_GET['argumento']), isset($_GET['orden']) ? $_GET['orden'] : 0);
        break;
    case 'filtrar':
        $resultados = filtrarRegistros($alumnos, $_GET['filtro'], strtolower($_GET['argumento']));
        break;
    case 'media':
        $resultados = calcularMedia($alumnos);
        break;
    case 'maximo':
        $resultados = obtenerMaximo($alumnos);
        break;
    case 'minimo':
        $resultados = obtenerMinimo($alumnos);
        break;
    default:
        header("Location: formulario.html");
        break;
}

function buscarRegistros($alumnos, $tipoFiltrado, $argumento, $orden){
    $criterio = "";
    switch ($tipoFiltrado){
        case 1:
            $criterio = 'nombre';
            break;
        case 2:
            $criterio = 'apellido1';
            break;
        case 3:
            $criterio = 'apellido2';
            break;
        case 4:
            $criterio = 'cuenta';
            break;
    }
    $resultados = array_filter($alumnos, function ($alumno) use ($criterio, $argumento){
        return strtolower($alumno[$criterio]) == $argumento;
    });
    usort($resultados, function ($alumno, $carry) use ($orden, $argumento){
        return $alumno[$orden] > $carry[$orden];
    });

    return $resultados;
}

function filtrarRegistros($alumnos, $tipoFiltrado, $argumento){
    $criterio = "";
    return array_filter($alumnos, function ($alumno) use ($tipoFiltrado, $argumento){
        if ($tipoFiltrado == 'mayor'){
            return $alumno['calificacion'] > $argumento;
        } else{
            return $alumno['calificacion'] < $argumento;
        }
    });

}

function calcularMedia($alumnos){
    $total = 0;
    foreach ($alumnos as $alumno) {
        $total += $alumno['calificacion'];
    }

    $media = round($total / count($alumnos));
    echo "La media es de <strong>{$media}</strong> puntos.";
    exit;
}

function obtenerMaximo($alumnos){
    $maximo = $alumnos[0];
    foreach ($alumnos as $alumno) {
        if ($maximo['calificacion'] < $alumno['calificacion']){
            $maximo = $alumno;
        }
    }

    echo "El alumno con máxima nota es {$maximo['nombre']} {$maximo['apellido1']} {$maximo['apellido2']} ({$maximo['cuenta']}) con {$maximo['calificacion']} puntos";
    exit;
}

function obtenerMinimo($alumnos){
    $minimo = $alumnos[0];
    foreach ($alumnos as $alumno) {
        if ($minimo['calificacion'] > $alumno['calificacion']){
            $minimo = $alumno;
        }
    }

    echo "El alumno con nota más baja es {$minimo['nombre']} {$minimo['apellido1']} {$minimo['apellido2']} ({$minimo['cuenta']}) con {$minimo['calificacion']} puntos";
    exit;
}
?>


<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica Anexo 3</title>
    <style>
        table {
            width: 100%;
        }
        th,td{
            border: 1px solid #333;
            padding: 5px;
        }
    </style>
</head>
<body>
<table>
    <thead>
    <tr>
        <th>Nombre</th>
        <th>Primer apellido</th>
        <th>Segundo apellido</th>
        <th>Cuenta</th>
        <th>Calificación</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($resultados as $resultado) : ?>
        <tr>
            <td><?php echo $resultado['nombre']; ?></td>
            <td><?php echo $resultado['apellido1']; ?></td>
            <td><?php echo $resultado['apellido2']; ?></td>
            <td><?php echo $resultado['cuenta']; ?></td>
            <td><?php echo $resultado['calificacion']; ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>