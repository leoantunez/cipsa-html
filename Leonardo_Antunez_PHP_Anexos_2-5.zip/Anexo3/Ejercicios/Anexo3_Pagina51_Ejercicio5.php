<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 51 Ejericio 5</title>
    <style>
        td, th {
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
<?php $cadena1 = "02394-45677-30950-34503" ?>
<?php $cadena2 = "01499-45677-45677-45679" ?>

<p>
    El serial <strong><?php echo $cadena1 ?></strong> es <strong><?php echo serialcheck($cadena1) ? "VÁLIDO" : "INVÁLIDO"; ?></strong>
</p>
<p>
    El serial <strong><?php echo $cadena2 ?></strong> es <strong><?php echo serialcheck($cadena2) ? "VÁLIDO" : "INVÁLIDO"; ?></strong>
</p>
</body>
</html>

