<?php

$cadena = "Estoy estudiando el capítulo relativo a las Cadenas de PHP";
echo sprintf("Cadena <strong>%s</strong>", $cadena);
echo "<br/>Cantidad de caracteres: ". strlen($cadena);
echo "<br/>Cantidad de caracteres excluyendo espacios: ". preg_match_all('/[^ i]/' , $cadena);
echo "<br/>Cadena expresada en mayúsculas: ". strtoupper($cadena);
echo "<br/>Longitud de la cadena: ". strlen($cadena);
echo "<br/>El texto existente en la cadena tras la palabra “las“: ". explode("las", $cadena)[1];
echo "<br/>La posición de la palabra “relativo“: ". strpos($cadena, "relativo");
echo "<br/>La subcadena que se inicia en el carácter 8o y finaliza en el 15o: ". substr($cadena,7, 8);
echo "<br/>La subcadena con los últimos cinco caracteres.: ". substr($cadena,-5);
echo "<br/>La cadena con la palabra “capítulo” reemplazada por “tema”: ". str_replace("capítulo","tema",$cadena);
echo "<br/>El número de “a” existentes en la cadena: ". preg_match_all('/a/' , $cadena);
echo "<br/>El número de palabras contenidas en la cadena: ". str_word_count($cadena);
preg_match_all('/[\w\í]+o\w*/' , $cadena, $palabras);
echo "<br/>Todas las palabras comprendidas en la cadena con una “o”: ". implode(", ", $palabras[0]);