<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 51 Ejericio 3</title>
    <style>
        td, th{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <?php $numero = mt_rand (100, 10000) / 10 ?>
    El número <strong><?php echo $numero ?></strong> se ha formateado como <strong><?php echo imprimirCadenaNumerica($numero) ?></strong>
</body>
</html>

