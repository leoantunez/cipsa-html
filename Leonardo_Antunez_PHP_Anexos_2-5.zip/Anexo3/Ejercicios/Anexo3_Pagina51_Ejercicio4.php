<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 51 Ejericio 4</title>
    <style>
        td, th {
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
<?php $cadena1 = "Esta cadena tiene más de 30 caracteres." ?>
<?php $cadena2 = "Cadena corta." ?>

<p>
    La cadena <strong><?php echo $cadena1 ?></strong> se ha convertido a
<pre>
    <?php var_dump(imprimirCadena($cadena1)); ?>
    </pre>
</p>
<p>
    La cadena <strong><?php echo $cadena2 ?></strong> se ha convertido a
<pre>
    <?php var_dump(imprimirCadena($cadena2)); ?>
    </pre>
</p>
</body>
</html>

