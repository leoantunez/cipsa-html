<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 29 Ejericio 4</title>
    <style>
        td, th{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>Código de color Azul</th>
            </tr>
        </thead>
        <tr>
            <td><?php obtenerCodigoColor("Azul");?></td>
        </tr>
    </table>
</body>
</html>

