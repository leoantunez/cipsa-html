<?php 
    
    require_once 'funciones.php'; 
    $lista1 = ["a", "b", "c", "d", "e"];
    $lista2 = ["v", "w", "x", "y", "z"];
 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 29 Ejericio 6</title>
    <style>
        td, th{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>Combina en el array “lista1” los valores que éste contiene junto con los del array “lista2”.</th>
            </tr>
        </thead>
        <tr>
            <td><?php 
            $lista1 = array_merge($lista1, $lista2);
            echo implode(', ', $lista1); ?></td>
        </tr>
    </table>


    <table>
        <thead>
            <tr>
                <th>Agrega al array “lista1” el elemento ‘6’ por la derecha y el elemento ‘1’ por la izquierda.</th>
            </tr>
        </thead>
        <tr>
            <td><?php 
            $lista1[] = 6;
            $lista1 = array_merge([1], $lista1);
            echo implode(', ', $lista1); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Elimina del array “lista1” los elementos insertados en el apartado anterior.</th>
            </tr>
        </thead>
        <tr>
            <td><?php 
            unset($lista1[0]);
            unset($lista1[11]);
            echo implode(', ', $lista1); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Añade al final del array “lista1” los elementos: ‘7’,’8’,’9’.</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php 
            $lista1 = array_merge($lista1, [7,8,9]);
            echo implode(', ', $lista1); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Elimina el último elemento del array "lista1" y muestra tanto el valor extraído como el array resultante.</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php 
            $ultimoElemento = array_pop($lista1);
            echo "Ultimo elemento: {$ultimoElemento} <br>";
            echo '$lista1: '. implode(', ', $lista1); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Elimina el primer elemento del array “lista1” y muestra tanto el valor extraído como el array resultante.</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php 
            $primerElemento = $lista1[0];
            unset($lista1[0]);
            echo "Primer elemento: {$primerElemento} <br>";
            echo '$lista1: '. implode(', ', $lista1); ?></td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Muestra el array "lista1" en orden inverso</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php 
            echo implode(', ', array_reverse($lista1)); ?></td>
        </tr>
    </table>



    <table>
        <thead>
            <tr>
                <th>Muestra el array "lista1" ordenado de menor a mayor, y de mayor a menor</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php 
                sort($lista1);
                echo "Menor a mayor " . implode(', ', $lista1);
                rsort($lista1);
                echo "<br > Mayor a menor " . implode(', ', $lista1);
             ?></td>
        </tr>
    </table>



    <table>
        <thead>
            <tr>
                <th>Indica si el elemento ‘e’ se encuentra contenido en el array “lista1”, y la posición que ocupa.</th>
            </tr>
        </thead>
        <tr>
            <td>
            <?php
                echo '$lista1: ' . implode(', ', $lista1).'<br/>';
                $posicion = array_search("e", $lista1);
                if ($posicion!= false){
                    echo "'e' ha sido encontrado. Se encuentra en la posición {$posicion}.";
                } else{
                    echo "'e' no ha sido encontrado.";
                }

             ?></td>
        </tr>
    </table>
</body>
</html>

