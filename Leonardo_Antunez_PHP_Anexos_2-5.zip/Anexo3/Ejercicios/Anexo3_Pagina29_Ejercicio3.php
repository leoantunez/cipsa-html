<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 29 Ejericio 3</title>
    <style>
        td, th{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th colspan="3">Matriz de muestra</th>
            </tr>
            <tr>
                <th colspan="3">
                <?php
                    $valores = [];
                    for ($i=0; $i < 15; $i++) { 
                        $valores[] = rand(1,40);
                    }  
                    echo implode(', ', $valores);          
                ?>
                </th>
            </tr>
            
        </thead>
        
        <tr>
            <td>Máximo</td>
            <td>Mínimo</td>
            <td>Media</td>
        </tr>
        <tr>
            <?php obtenerResumenMatriz($valores);?>
        </tr>
    </table>
</body>
</html>

