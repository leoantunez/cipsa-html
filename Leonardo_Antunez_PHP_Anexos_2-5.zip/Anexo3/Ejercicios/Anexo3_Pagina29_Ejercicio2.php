<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 29 Ejericio 1</title>
    <style>
        td{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th colspan="2">Asistencia laboral por días</th>
            </tr>
        </thead>
        <?php
            $matriz = [
                "Domingo" => "0", 
                "Lunes" => "2", 
                "Martes" => "9", 
                "Miércoles" => "10", 
                "Jueves" => "10", 
                "Viernes" => "6", 
                "Sábado" => "1"
            ];
            imprimirMatriz($matriz);
         ?>

    </table>
</body>
</html>

