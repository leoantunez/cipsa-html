<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 51 Ejericio 2</title>
    <style>
        td, th{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <?php if (compararCadenas("Hola Mundo", "hola mundo")) :?>
        <strong>"Hola Mundo"</strong> es igual a <strong>"hola mundo"</strong> sin considerar diferencias entre mayúsculas y minúsculas
    <?php endif;?>
</body>
</html>

