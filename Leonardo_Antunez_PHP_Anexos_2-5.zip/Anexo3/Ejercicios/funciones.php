<?php 

/**
 * Ejercicios 1 y 2
 */
function imprimirMatriz($matriz){
    foreach($matriz as $posicion => $elemento){
        echo "<tr><td>{$posicion}</td><td>{$elemento}</td></tr>";
    }
}

/**
 * Ejericio 3
 */
function obtenerResumenMatriz($matriz){
    $maximo = max($matriz);
    $minimo = min($matriz);
    $sumatoria = 0;
    foreach ($matriz as $valor) {
        $sumatoria+=$valor;
    }
    $media = round($sumatoria/count($matriz), 2);
    echo "<tr><td>{$maximo}</td><td>{$minimo}</td><td>{$media}</td></tr>";
}

/**
 * Ejercicio 4
 */
function obtenerCodigoColor($color){
    $colores = [
        "Azul" => "#0000FF",
        "Rojo" => "#FF0000",
        "Magenta" => "#FF00FF",
        "Verde" => "#00FF000",
        "Cyan" => "#00FFFF",
        "Amarillo" => "#FFFF00",
        "Blanco" => "#FFFFFF",
    ];
    if (!array_key_exists($color, $colores)){
        echo "El color no está registrado";
        return;
    }

    echo $colores[$color];
}

/**
 * Ejercicio 5
 */
function calcularMatrizTablaMultiplicacion(){
    $tabla = [];
    for ($i=1; $i <= 10; $i++) { 
        for ($j=1; $j <= 10; $j++) { 
            $tabla[$i][$j] = $i * $j;
        }
    }
    return $tabla;
}

/**
 * Ejercicio 5
 */
function mostrarMatrizTablaMultiplicacion($tabla){
    foreach ($tabla as $producto1 => $resultados) {
        echo "<tr>";
        foreach ($resultados as $producto2 => $resultado) {
            echo "<td>{$resultado}</td>";
        }
        echo "</tr>";
    }
}

/**
 * Ejercicio 2 Pag 51
 */
function compararCadenas($cadena1, $cadena2){
    return strcasecmp($cadena1, $cadena2) == 0;
}

/**
 * Ejercicio 3 Pag 51
 */
function imprimirCadenaNumerica($numero){
    return sprintf("#%s#", number_format($numero, 2));
}

/**
 * Ejercicio 4 Pag 51
 */
function imprimirCadena($cadena){
    if (strlen($cadena) > 30){
        return substr($cadena, 0, 30);
    }
    return str_pad($cadena, 30);
}

/**
 * Ejercicio 5 Pag 51
 */
function serialcheck($cadena){
    return preg_match_all('/^(([02468][13579][02468]\d[13579])-){3}([02468][13579][02468]\d[13579])$/', $cadena);
}