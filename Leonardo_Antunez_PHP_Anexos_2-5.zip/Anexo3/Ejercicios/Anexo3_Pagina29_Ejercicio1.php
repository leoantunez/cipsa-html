<?php require_once 'funciones.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 3 Pagina 29 Ejericio 1</title>
    <style>
        td{
            border: 1px solid #000;
            padding: 10px;
        }
    </style>
</head>
<body>
    <table>
        <?php
            $matriz = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
            imprimirMatriz($matriz);
         ?>

    </table>
</body>
</html>

