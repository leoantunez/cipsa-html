<?php
require 'funciones.php';
validarSesion();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ingreso</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="text-center">

<main class="form-signin">
    <form action="funciones.php" method="post">
        <h1 class="h3 mb-3 fw-normal">Nuevo ingreso</h1>

        <div class="form-floating">
            <input min="1" max="9999" type="number" name="cantidad" class="form-control" id="floatingInput" >
            <label for="floatingInput">Cantidad</label>
        </div>
        <input type="hidden" value="ingreso" name="accion">
        <button class="w-100 mt-4 btn btn-lg btn-primary" type="submit">Ingresar</button>
    </form>
</main>



</body>
</html>