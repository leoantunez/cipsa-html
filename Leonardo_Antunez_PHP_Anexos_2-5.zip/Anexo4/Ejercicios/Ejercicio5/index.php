<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gestión bancaria</title>
    <base href="" target="_blank">
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="text-center">

<main class="form-signin">
    <form action="funciones.php" method="post">
        <h1 class="h3 mb-3 fw-normal">Inicie sesión</h1>

        <div class="form-floating">
            <input type="text" name="cuenta" class="form-control" id="floatingInput" >
            <label for="floatingInput">Número de cuenta</label>
        </div>
        <div class="form-floating">
            <input type="password" name="pin" class="form-control" id="floatingPassword">
            <label for="floatingPassword">PIN</label>
        </div>
        <input type="hidden" value="login" name="accion">
        <button class="w-100 btn btn-lg btn-primary" type="submit">Acceder</button>
    </form>
</main>



</body>
</html>