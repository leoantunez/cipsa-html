<?php
session_start();
function iniciarSesion()
{
    if (isset($_POST['cuenta']) && isset($_POST['pin'])) {
        $datosCuenta = autenticarUsuario($_POST['cuenta'], $_POST['pin']);
        if ($datosCuenta !== false) {
            setcookie("ultimo_accesso", date('Y-m-d H:i'), time()+36000);
            $_SESSION['cuenta'] = $datosCuenta;
            header('Location: gestion.php');
        } else {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Acceso denegado</h1>';
            exit;
        }
    }
}

function validarSesion()
{
    if (!array_key_exists("cuenta", $_SESSION) || !$_SESSION["cuenta"]) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>Acceso denegado</h1>';
        exit;
    }

}

function obtenerNombreCuenta(){
    return "{$_SESSION['cuenta'][2]} {$_SESSION['cuenta'][3]}";
}

function obtenerSaldoCuenta(){
    return floatval($_SESSION['cuenta'][4]);
}

function autenticarUsuario($identificador, $pin)
{
    $cuentas = explode("\n", file_get_contents(__DIR__ . '/cuentas.dat'));
    foreach ($cuentas as $cuenta) {
        if (!$cuenta){
            continue;
        }
        $datosCuenta = explode(',', $cuenta);
        if (trim($datosCuenta[0]) === $identificador && trim($datosCuenta[1]) === $pin){
            return $datosCuenta;
        }
    }

    return false;

}

function procesarIngreso(){
    if (isset($_POST['cantidad']) && floatval($_POST['cantidad']) > 0 && floatval($_POST['cantidad']) < 10000 ) {
        $cuentaUsuario = $_SESSION['cuenta'][0];
        $datosActuales = "";
        $cuentas = explode("\n", file_get_contents(__DIR__ . '/cuentas.dat'));
        foreach ($cuentas as $cuenta) {
            if (!$cuenta){
                continue;
            }
            $datosCuenta = explode(',', $cuenta);
            if (trim($datosCuenta[0]) === $cuentaUsuario){
                $nuevoSaldo = floatval($datosCuenta[4]) + floatval($_POST['cantidad']);
                $nuevaEntrada = "$datosCuenta[0],$datosCuenta[1],$datosCuenta[2],$datosCuenta[3],$nuevoSaldo";
                $datosActuales = sprintf("%s\n%s", $datosActuales, $nuevaEntrada);
                $datosCuenta[4] = $nuevoSaldo;
                $_SESSION['cuenta'] = $datosCuenta;
            } else{
                $datosActuales = sprintf("%s\n%s", $datosActuales, $cuenta);
            }
        }
        file_put_contents(__DIR__ . '/cuentas.dat', $datosActuales);
        header('Location: gestion.php');
    } else{
        header('HTTP/1.0 400 Bad Request');
        echo '<h1>La cantidad entrada debe ser mayor que cero y menor a 10000</h1>';
        exit;
    }
}

function procesarReintegro(){
    if (isset($_POST['cantidad']) && floatval($_POST['cantidad']) > 0 && floatval($_POST['cantidad']) < obtenerSaldoCuenta() ) {
        $cuentaUsuario = $_SESSION['cuenta'][0];
        $datosActuales = "";
        $cuentas = explode("\n", file_get_contents(__DIR__ . '/cuentas.dat'));
        foreach ($cuentas as $cuenta) {
            if (!$cuenta){
                continue;
            }
            $datosCuenta = explode(',', $cuenta);
            if (trim($datosCuenta[0]) === $cuentaUsuario){
                $nuevoSaldo = floatval($datosCuenta[4]) - floatval($_POST['cantidad']);
                $nuevaEntrada = "$datosCuenta[0],$datosCuenta[1],$datosCuenta[2],$datosCuenta[3],$nuevoSaldo";
                $datosActuales = sprintf("%s\n%s", $datosActuales, $nuevaEntrada);
                $datosCuenta[4] = $nuevoSaldo;
                $_SESSION['cuenta'] = $datosCuenta;
            } else{
                $datosActuales = sprintf("%s\n%s", $datosActuales, $cuenta);
            }
        }
        file_put_contents(__DIR__ . '/cuentas.dat', $datosActuales);
        header('Location: gestion.php');
    } else{
        header('HTTP/1.0 400 Bad Request');
        echo '<h1>La cantidad entrada debe ser mayor que cero y menor a 10000</h1>';
        exit;
    }
}



if (array_key_exists("accion", $_POST) && $_POST["accion"]) {
    switch ($_POST['accion']) {
        case 'login':
            iniciarSesion();
            break;
        case 'ingreso':
            procesarIngreso();
            break;
        case 'reintegro':
            procesarReintegro();
            break;
        default:
            header('HTTP/1.0 400 Bad Request');
            echo '<h1>Acción no reconocida</h1>';
            exit;
    }
}