<?php
require 'funciones.php';
validarSesion();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gestión bancaria</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body >

<main class="container-fluid text-center">
    <div class="row justify-content-center">
        <div class="col-6">
            <h1>Bienvenido <?php echo obtenerNombreCuenta() ?></h1>
            <p class="mt-3 mb-3">Último acceso: <?php echo $_COOKIE['ultimo_accesso']?></p>
            <h3>Saldo actual : <u>$<?php echo obtenerSaldoCuenta()?></u></h3>
        </div>
    </div>
    <div class="row justify-content-center mt-3">
        <div class="col-1">
            <a href="ingreso.php" class="btn btn-block w-100 btn-outline-success">Ingreso</a>
        </div>
        <div class="col-1">
            <a href="reintegro.php" class="btn btn-block w-100 btn-outline-danger">Reintegro</a>
        </div>
    </div>
</main>



</body>
</html>