<?php
session_start();
function autenticarUsuario($usuario, $contra)
{
    $listado = explode("\n", file_get_contents(__DIR__ . "/psw.dat"));
    foreach ($listado as $datosUsuario) {
        if ($datosUsuario === "$usuario,$contra") {
            return true;
        }
    }
    return false;
}

function obtenerMensajes()
{
    $mensajes = explode("\n", file_get_contents(__DIR__ . "/foro.dat"));
    $datos = [];
    foreach ($mensajes as $mensaje) {
        if (!$mensaje) {
            continue;
        }
        $datosMensaje = explode('||', $mensaje);
        $datos[] = [
            'mensaje' => $datosMensaje[0],
            'autor' => $datosMensaje[1],
            'fecha' => new DateTime($datosMensaje[2]),
        ];
    }
    return $datos;
}

function iniciarSesion()
{
    if (isset($_POST['usuario']) && isset($_POST['contra'])) {
        if (autenticarUsuario($_POST['usuario'], $_POST['contra'])) {
            $usuario = filter_input(INPUT_POST, 'usuario');
            $_SESSION['usuario'] = $usuario;
        } else {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Acceso denegado</h1>';
            exit;
        }
    }
}

function enviarMensaje(){
    if (isset($_POST['mensaje'])){
        $fecha = date('Y-m-d H:i');
        $mensaje = "{$_POST['mensaje']}||{$_SESSION['usuario']}||$fecha\n";
        file_put_contents(__DIR__ . "/foro.dat", $mensaje, FILE_APPEND);
    } else{
        header('HTTP/1.0 400 Bad Request');
        echo '<h1>No es posible publicar el mensaje</h1>';
        exit;
    }
}

if (isset($_REQUEST['accion'])) {
    switch ($_REQUEST['accion']) {
        case 'iniciar_sesion':
            iniciarSesion();
            break;
        case 'enviar_mensaje':
            enviarMensaje();
            break;
        default:
            header('HTTP/1.0 400 Bad Request');
            echo '<h1>Accion desconocida</h1>';
            exit;
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 4 Pagina 41 Ejericio 2</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
<main>
    <aside>
        <div class="formulario">
            <?php if (isset($_SESSION['usuario'])) { ?>
                <h3>Hola <?php echo $_SESSION['usuario'] ?></h3>
                <form method="post" action="Anexo4_Pagina41_Ejercicio2.php?accion=enviar_mensaje">
                    <label for="mensaje">Mensaje</label>
                    <textarea required name="mensaje" id="mensaje" rows="10" style="resize: none; width: 100%;"></textarea>

                    <button type="submit" id="boton">Enviar mensaje</button>
                </form>
            <?php } else { ?>
                <form method="post" action="Anexo4_Pagina41_Ejercicio2.php?accion=iniciar_sesion">
                    <label for="usuario">Usuario</label>
                    <input type="text" name="usuario" id="usuario" required>

                    <label for="contra">Contraseña</label>
                    <input type="password" name="contra" id="contra" required>

                    <button type="submit" id="boton">Iniciar sesión</button>
                </form>
            <?php } ?>

        </div>
    </aside>
    <section id="foro">
        <?php $mensajes = obtenerMensajes(); ?>
        <?php foreach ($mensajes as $mensaje) : ?>
            <div class="mensaje">
                <p><?php echo $mensaje['mensaje'] ?></p>
                <small><?php echo $mensaje['autor'] ?></small>
                <small><?php echo $mensaje['fecha']->format("d/m/Y") ?></small>
            </div>
        <?php endforeach; ?>
    </section>
</main>
</body>
</html>

