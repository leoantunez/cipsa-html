<?php
    function autenticarUsuario($usuario, $contra){
        $listado = explode("\n", file_get_contents(__DIR__."/psw.dat"));
        foreach ($listado as $datosUsuario) {
            if ($datosUsuario === "$usuario,$contra"){
                return true;
            }
        }
        return false;
    }
    if (isset($_POST['usuario']) && isset($_POST['contra'])){
        if (autenticarUsuario($_POST['usuario'], $_POST['contra'])){
            echo "<h1>Bienvenido {$_POST['usuario']}</h1>";
            exit;
        } else{
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Acceso denegado</h1>';
            exit;
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 4 Pagina 41 Ejericio 1</title>
    <style>
        .formulario{
            width: 300px;
            border: 1px solid #dedede;
            margin: 0 auto;
            padding: 15px;
        }
        .formulario label, .formulario input{
            margin-top: 5px;
            display: block;
            width: 100%;
        }

        #boton{
            margin: 20px auto;
            width: 70%;

        }
    </style>
</head>
<body>
    <div class="formulario">
        <form method="post" action="Anexo4_Pagina41_Ejercicio1.php">
            <label for="usuario">Usuario</label>
            <input type="text" name="usuario" id="usuario" required>

            <label for="contra">Contraseña</label>
            <input type="password" name="contra" id="contra" required>

            <button type="submit" id="boton">Iniciar sesión</button>
        </form>
    </div>
</body>
</html>

