<?php
function procesarVoto(){
    $voto = "{$_POST['nombre']}||{$_POST['apellidos']}||{$_POST['dni']}||{$_POST['fechaNacimiento']}||{$_POST['candidato']}\n";
    file_put_contents(__DIR__ . "/votos.dat", $voto, FILE_APPEND);
}

if (
array_key_exists("nombre", $_POST) && $_POST["nombre"]
&& array_key_exists("apellidos", $_POST) && $_POST["apellidos"]
&& array_key_exists("dni", $_POST) && $_POST["dni"]
&& array_key_exists("fechaNacimiento", $_POST) && $_POST["fechaNacimiento"]
&& array_key_exists("candidato", $_POST) && $_POST["candidato"]
) {
 procesarVoto();
}


?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro de votaciones</title>
    <style>
        .grupo label, .grupo input {
            display: block;
            margin-bottom: 10px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<main>
    <form action="" method="post">
        <fieldset>
            <legend>Datos generales</legend>

            <div class="grupo">
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre">
            </div>

            <div class="grupo">
                <label for="apellidos">Apellidos</label>
                <input type="text" name="apellidos" id="apellidos">
            </div>

            <div class="grupo">
                <label for="dni">DNI</label>
                <input type="text" name="dni" id="dni">
            </div>

            <div class="grupo">
                <label for="fechaNacimiento">Fecha de nacimiento</label>
                <input type="date" name="fechaNacimiento" id="fechaNacimiento">
            </div>
        </fieldset>
        <fieldset>
            <legend>Seleccione un candidato</legend>
            <label>
                <input type="radio" name="candidato" value="Candidato 1">
                Candidato 1
            </label>
            <label>
                <input type="radio" name="candidato" value="Candidato 2">
                Candidato 2
            </label>
            <label>
                <input type="radio" name="candidato" value="Candidato 3">
                Candidato 3
            </label>
        </fieldset>
        <div class="grupo">
            <input type="submit" value="VOTAR">
        </div>
    </form>
</main>
</body>
</html>
