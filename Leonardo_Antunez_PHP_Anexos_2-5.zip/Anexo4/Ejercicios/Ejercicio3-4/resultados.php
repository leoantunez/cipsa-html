<?php
session_start();
function autenticarUsuario($usuario, $contra)
{
    return $usuario === "alumno" && $contra === "cipsa";
}

function obtenerResultados()
{
    $votos = explode("\n", file_get_contents(__DIR__ . "/votos.dat"));
    $votosPorCandidato = [];
    $cantidadVotos = 0;
    foreach ($votos as $voto) {
        if (!$voto) {
            continue;
        }
        $cantidadVotos++;
        $datosVoto = explode('||', $voto);
        $votosPorCandidato[$datosVoto[4]][] = $datosVoto;
    }
    return [
        'votosPorCandidato' => $votosPorCandidato,
        'totalVotos' => $cantidadVotos
    ];
}

function iniciarSesion()
{
    if (isset($_POST['usuario']) && isset($_POST['contra'])) {
        if (autenticarUsuario($_POST['usuario'], $_POST['contra'])) {
            $usuario = filter_input(INPUT_POST, 'usuario');
            $_SESSION['usuario'] = $usuario;
        } else {
            header('HTTP/1.0 403 Forbidden');
            echo '<h1>Acceso denegado</h1>';
            exit;
        }
    }
}

if (
        array_key_exists("usuario", $_POST) && $_POST["usuario"]
    && array_key_exists("contra", $_POST) && $_POST["contra"]
){
    iniciarSesion();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anexo 4 Pagina 41 Ejericio 2</title>
    <style>
        td,th{
            border: 1px solid #dedede;
        }
    </style>
</head>
<body>
<main>
    <?php if (!isset($_SESSION['usuario'])) { ?>
        <form method="post" action="resultados.php">
            <label for="usuario">Usuario</label>
            <input type="text" name="usuario" id="usuario" required>

            <label for="contra">Contraseña</label>
            <input type="password" name="contra" id="contra" required>

            <button type="submit" id="boton">Iniciar sesión</button>
        </form>
    <?php } else { ?>
        <table>
            <tr>
                <th>Candidato</th>
                <th>Porcentage de votos</th>
            </tr>
            <?php $resultados = obtenerResultados(); ?>
            <?php foreach ($resultados['votosPorCandidato'] as $candidato => $votos) : ?>
                <tr class="voto">
                    <td><?php echo $candidato ?></td>
                    <td><?php echo round(count($votos) * 100 / $resultados['totalVotos']) ?>%</td>
                </tr>
            <?php endforeach; ?>
        </table>
        <section id="foro">

        </section>
    <?php } ?>

</main>
</body>
</html>

