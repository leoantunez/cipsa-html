<?php
require 'funciones.php';
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Foro</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body >

<main>
    <div class="container">
        <div class="row mt-4" >
            <div class="col-9">
                <h1 class="h3 mb-3 fw-normal">Foro</h1>
            </div>
            <div class="col-3">
                <a class="btn w-100 btn-outline-primary" href="publicacion.php">Publicar nuevo mensaje</a>
            </div>
        </div>


        <?php $mensajes = obtenerMensajes() ?>
        <?php foreach ($mensajes as $mensaje) : ?>
            <div class="card mb-3">
                <div class="card-header">
                    <div class="row">
                        <div class="col-1">
                            <img class="w-100" src="perfiles/<?php echo $mensaje['usuario']; ?>.jpg" alt="">
                        </div>
                        <div class="col-10">
                            <h4 class="card-title"><?php echo $mensaje['usuario']; ?></h4>
                            <time ><?php echo $mensaje['fecha']->format('d/m/Y h:i A'); ?></time>
                        </div>
                    </div>


                </div>
                <div class="card-body">
                    <?php echo $mensaje['mensaje']; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>


</body>
</html>