<?php
session_start();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro de usuarios</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="text-center">

<main class="form-signin">

    <form action="funciones.php" method="post" enctype="multipart/form-data">

        <h1 class="h3 mb-3 fw-normal">Registre su cuenta</h1>
        <?php if ($_SESSION['errores_registro']) : ?>
            <div class="alert alert-danger text-start">
                <h4>Se han detectado los siguientes errores en el formulario de registro</h4>
                <ul>
                    <?php foreach ($_SESSION['errores_registro'] as $error) : ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach;?>
                </ul>
            </div>
            <?php unset($_SESSION['errores_registro']); ?>
        <?php endif; ?>
        <div class="form-floating">
            <input type="text" name="nombre_usuario" class="form-control" id="floatingInput" >
            <label for="floatingInput">Nombre de usuario</label>
        </div>
        <div class="form-floating">
            <input type="password" name="contrasena" class="form-control" id="floatingPassword">
            <label for="floatingPassword">Contraseña</label>
        </div>
        <div class="form-floating">
            <input type="password" name="contrasena_repetida" class="form-control" id="floatingPassword2">
            <label for="floatingPassword2">Repita contraseña</label>
        </div>
        <div class="form-floating">
            <input type="file"  name="foto_perfil" class="form-control" id="foto_perfil">
            <label style="margin-bottom: 10px" for="foto_perfil">Foto de perfil</label>
        </div>
        <input  type="hidden" value="registro" name="accion">
        <button class="w-100 btn btn-lg btn-primary" type="submit">Registrarme</button>
    </form>
</main>


</body>
</html>