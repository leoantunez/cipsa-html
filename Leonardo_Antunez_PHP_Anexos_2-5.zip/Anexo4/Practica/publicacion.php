<?php
require 'funciones.php';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Publicar mensaje</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<main class="form-signin">
    <h1 class="mb-4 text-center">Publicar nuevo mensaje</h1>
    <form action="funciones.php" method="post" enctype="multipart/form-data">
        <?php if ($_SESSION['errores_publicacion']) : ?>
            <div class="alert alert-danger text-start">
                <h4>Se han detectado los siguientes errores.</h4>
                <ul>
                    <?php foreach ($_SESSION['errores_publicacion'] as $error) : ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach;?>
                </ul>
            </div>
            <?php unset($_SESSION['errores_publicacion']); ?>
        <?php endif; ?>
        <div class="form-group">
            <label for="floatingInput">Nombre de usuario</label>
            <input type="text" name="nombre_usuario" class="form-control" id="floatingInput" >
        </div>
        <div class="form-group">
            <label for="floatingPassword">Contraseña</label>
            <input type="password" name="contrasena" class="form-control" id="floatingPassword">
        </div>
        <div class="form-group">
            <label for="mensaje">Mensaje</label>
            <textarea name="mensaje" class="form-control" id="mensaje" rows="8"></textarea>
        </div>
        <input  type="hidden" value="publicar" name="accion">
        <button class="mt-4 w-100 btn btn-lg btn-primary" type="submit">Publicar</button>
    </form>
</main>


</body>
</html>