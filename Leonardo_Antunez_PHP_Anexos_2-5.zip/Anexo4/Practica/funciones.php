<?php
session_start();
function publicarMensaje()
{
    $errores = validarMensaje();
    if (empty($errores)) {
        $hoy = new \DateTime('now');
        $mensaje = str_replace("<", "", $_POST['mensaje']);
        $mensaje = str_replace(">", "", $mensaje);
        $entrada = <<<EOD
<mensaje>
{$_POST['nombre_usuario']}
{$hoy->format('Y-m-d H:i')}
{$mensaje}
</mensaje>
EOD;
        file_put_contents(__DIR__ . "/foro/mensajes.dat", $entrada, FILE_APPEND);
        header('Location: foro.php');
    } else {
        $_SESSION['errores_publicacion'] = $errores;
        header('Location: publicacion.php');
    }
}

function validarSesion()
{
    if (!array_key_exists("cuenta", $_SESSION) || !$_SESSION["cuenta"]) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>Acceso denegado</h1>';
        exit;
    }
}

function validarMensaje()
{
    $errores = [];
    if (!isset($_POST['mensaje']) || !$_POST['mensaje']) {
        $errores[] = "El mensaje es requerido";
    }
    if (!isset($_POST['nombre_usuario']) || !$_POST['nombre_usuario']) {
        $errores[] = "El nombre de usuario es requerido";
    }
    if (!isset($_POST['contrasena']) || !$_POST['contrasena']) {
        $errores[] = "La contraseña es requerida";
    }
    if (!autenticarUsuario($_POST['nombre_usuario'], $_POST['contrasena'])){
        $errores[] = "El usuario o contraseña introducidos son incorrectos";
    }
    return $errores;
}


function autenticarUsuario($usuario, $contrasena)
{
    $cuentas = explode("\n", file_get_contents(__DIR__ . '/perfiles/usuarios.dat'));
    foreach ($cuentas as $cuenta) {
        if (!$cuenta) {
            continue;
        }
        $datosCuenta = explode(',', $cuenta);
        if (trim($datosCuenta[0]) === $usuario && trim($datosCuenta[1]) === $contrasena) {
            return $datosCuenta;
        }
    }

    return false;
}

function validarDatosRegistro()
{
    $errores = [];
    if (!isset($_POST['nombre_usuario']) || !$_POST['nombre_usuario']) {
        $errores[] = "El nombre de usuario es requerido";
    }
    if (!isset($_POST['contrasena']) || !$_POST['contrasena']) {
        $errores[] = "La contraseña es requerida";
    }
    if (!isset($_POST['contrasena_repetida']) || !$_POST['contrasena_repetida']) {
        $errores[] = "La comprobación de contraseña es requerida";
    }
    if ((isset($_POST['contrasena_repetida']) && isset($_POST['contrasena_repetida'])) && $_POST['contrasena_repetida'] !== $_POST['contrasena']) {
        $errores[] = "Las contraseñas deben ser iguales";
    }
    if (str_contains($_POST['nombre_usuario'], ',') || str_contains($_POST['contrasena'], ',')) {
        $errores[] = 'Los campos nombre de usuario y contraseña no deben contener comas';
    }
    if (!isset($_FILES['foto_perfil']) || !$_FILES['foto_perfil']) {
        $errores[] = "La foto de perfil es requerida";
    }
    if ($_FILES['foto_perfil']['size'] > 512000) {
        $errores[] = "El tamaño de la foto de perfil no puede exceder los 500Kb";
    }
    if ($_FILES['foto_perfil']['type'] !== 'image/jpeg') {
        $errores[] = "El formato de la foto de perfil debe ser JPG";
    }

    return $errores;
}

function procesarRegistro()
{
    $erroresRegistro = validarDatosRegistro();
    if (empty($erroresRegistro)) {
        $entrada = "{$_POST['nombre_usuario']},{$_POST['contrasena']}\n";
        file_put_contents(__DIR__ . "/perfiles/usuarios.dat", $entrada, FILE_APPEND);
        move_uploaded_file($_FILES['foto_perfil']['tmp_name'], __DIR__ . "/perfiles/{$_POST['nombre_usuario']}.jpg");
    } else {
        $_SESSION['errores_registro'] = $erroresRegistro;
        header('Location: registro.php');
    }
}

function obtenerMensajes()
{
    $lecturaFichero = file_get_contents(__DIR__ . "/foro/mensajes.dat");
    preg_match_all('/\<mensaje\>(?<mensaje>[^\<]*)\<\/mensaje\>/', $lecturaFichero, $mensajesFichero, PREG_SET_ORDER, 0);
    $mensajes = [];
    foreach ($mensajesFichero as $mensajeFichero) {
        if (!$mensajeFichero) {
            continue;
        }
        $datosMensajeFichero = explode("\n", $mensajeFichero['mensaje'], 4);
        $mensajes [] = [
            'usuario' => $datosMensajeFichero[1],
            'fecha' => new \DateTime($datosMensajeFichero[2]),
            'mensaje' => $datosMensajeFichero[3],
        ];
    }

    return $mensajes;
}


if (array_key_exists("accion", $_POST) && $_POST["accion"]) {
    switch ($_POST['accion']) {
        case 'publicar':
            publicarMensaje();
            break;
        case 'registro':
            procesarRegistro();
            break;
        default:
            header('HTTP/1.0 400 Bad Request');
            echo '<h1>Acción no reconocida</h1>';
            exit;
    }
}