<?php
require 'automovil.class.php';

$matrizInicial = [
    [
        'matricula' => '4383-SA',
        'marca' => 'Seat',
        'modelo' => 'Toledo',
        'combustible' => '24.56',
    ],
    [
        'matricula' => '3949-SS',
        'marca' => 'Citron',
        'modelo' => 'Saxo',
        'combustible' => '20.345',
    ],
    [
        'matricula' => '7644-GH',
        'marca' => 'Peugeot',
        'modelo' => '307',
        'combustible' => '14.56',
    ],
    [
        'matricula' => '4955-FF',
        'marca' => 'Fiat',
        'modelo' => 'Punto',
        'combustible' => '37.54',
    ]
];
$automoviles = [];
foreach ($matrizInicial as $item) {
    $automovil = new automovil(
        $item['matricula'],
        $item['marca'],
        $item['modelo'],
        $item['combustible'],
    );
    $automoviles[] = $automovil;
}

?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listado de vehiculos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <main>
        <h1>Listado de vehiculos</h1>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>Matrícula</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Combustible</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($automoviles as $automovil):?>
                <tr>
                    <?php $automovil->mostrar(); ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
