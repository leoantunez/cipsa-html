<?php

class automovil{
    private $matricula;
    private $modelo;
    private $marca;
    private $combustible;

    public function __construct($matricula,  $marca,$modelo, $combustible)
    {
        $this->matricula = $matricula;
        $this->modelo = $modelo;
        $this->marca = $marca;
        $this->combustible = $combustible;
    }

    public function mostrar()
    {
        echo "<tr><td>{$this->matricula}</td><td>{$this->marca}</td><td>{$this->modelo}</td><td>{$this->combustible}</td></tr>";
    }


}
