<?php

class dni
{
    private $numero;
    private $letra;
    private $dni;

    private $matrizLetras = [
        0 => "T",
        1 => "R",
        2 => "W",
        3 => "A",
        4 => "G",
        5 => "M",
        6 => "Y",
        7 => "F",
        8 => "P",
        9 => "D",
        10 => "X",
        11 => "B",
        12 => "N",
        13 => "J",
        14 => "Z",
        15 => "S",
        16 => "Q",
        17 => "V",
        18 => "H",
        19 => "L",
        20 => "C",
        21 => "K",
        22 => "E",
    ];

    public function __construct($_dni)
    {
        $this->numero = intval(substr($_dni, 0, 8));
        $this->letra = substr($_dni, 8, 1);
        $this->dni = $_dni;
    }

    public function getNumero()
    {
        return $this->numero;
    }

    public function getLetra()
    {
        return $this->letra;
    }

    public function validar()
    {
        if (!preg_match('/(\d){8}[A-Z]{1}/', $this->dni)) {
            return false;
        }
        $resto = $this->numero % 23;
        if ($this->matrizLetras[$resto] !== $this->letra){
            return false;
        }

        return true;
    }
}

$dni = new dni("12345678Z");
$resultdo = $dni->validar();
if ($resultdo === true) {
    echo "EL DNI ES VALIDO";
} else {
    echo "EL DNI NO ES VALIDO";
}
