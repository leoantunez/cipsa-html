<?php

class persona{
    private $nombre;

    public function __construct($nombre)
    {
        $this->nombre = $nombre;
    }

    public function Saludar(){
        echo "Hola {$this->nombre}";
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function setNombre($nombre): void
    {
        $this->nombre = $nombre;
    }
}


$persona = new persona("Leonardo");
$persona->Saludar();
$persona->setNombre("Juan");
$persona->Saludar();
