<?php

class persona{
    private $nombre;

    public function __construct($nombre)
    {
        $this->nombre = $nombre;
    }

    public function Saludar(){
        echo "Hola {$this->nombre}";
    }
}


$persona = new persona("Leonardo");
$persona->Saludar();