<?php

require_once 'clases/controls.class.php';
$txt_cifra = new textbox("txt_cifra");
$lst_moneda = new listbox("lst_moneda");
$lst_moneda->opcion(new listboxopcion("EURO -> DOLAR", 1));
$lst_moneda->opcion(new listboxopcion("DOLAR -> EURO", 2));

if ($txt_cifra->getValor() && floatval($txt_cifra->getValor()) > 0 && $lst_moneda->getValor()){
    $resultado = null;
    switch ($lst_moneda->getValor()){
        case 1:
            $resultado = $txt_cifra->getValor() * 1.05232;
            break;
        case 2:
            $resultado = $txt_cifra->getValor() * 0.95022;
            break;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Selecciona una imagen para subirla al servidor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <form action="ej1.php" method="post">
        <h1>CAMBIO MONEDA</h1>
        CANTIDAD: <?php $txt_cifra->html(); ?><br/>
        MONEDA: <?php $lst_moneda->html(); ?>
        <input type="submit" value="CALCULAR">

        <?php if (isset($resultado) && $resultado) :?>
            <div class="alert alert-info mt-4">
                <h3>Resultado de la conversión: <?php echo number_format($resultado, 2); ?></h3>
            </div>
        <?php endif; ?>
    </form>
</div>
</body>
</html>
