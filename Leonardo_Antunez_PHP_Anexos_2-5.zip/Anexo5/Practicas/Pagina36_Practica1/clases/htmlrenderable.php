<?php

interface htmlrenderable
{
    function html();
}