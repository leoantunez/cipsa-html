<?php
require_once __DIR__ . "/../clases/tarifa_pizza.class.php";
require_once __DIR__ . "/../clases/tarifa_ingrediente.class.php";

$_pizzas["napolitana"] = new tarifa_pizza("napolitana", 4.00, 4.50, 5.20);
$_pizzas["new york"] = new tarifa_pizza ("new york", 4.20, 4.80, 5.50);
$_pizzas["pizza de taglio"] = new tarifa_pizza ("pizza de taglio", 5.20, 5.80, 6.50);
$_pizzas["argentina"] = new tarifa_pizza ("argentina", 6.00, 6.80, 7.20);
$_pizzas["chicago"] = new tarifa_pizza ("chicago", 4.20, 4.50, 5.00);
$_pizzas["sfincione"] = new tarifa_pizza ("sfincione", 5.80, 6.20, 6.50);

$_ingredientes["anchoas"] = new tarifa_ingrediente ("anchoas", 0.25, 0.3);
$_ingredientes["atun"] = new tarifa_ingrediente ("atun", 0.25, 0.35);
$_ingredientes["bacon"] = new tarifa_ingrediente ("bacon", 0.2, 0.4);
$_ingredientes["carne vacuno"] = new tarifa_ingrediente ("carne vacuno", 0.2, 0.45);
$_ingredientes["cebolla"] = new tarifa_ingrediente ("cebolla", 0.1, 0.15);
$_ingredientes["cerdo"] = new tarifa_ingrediente ("cerdo", 0.4, 0.65);
$_ingredientes["champinon"] = new tarifa_ingrediente ("champinon", 0.2, 0.4);
$_ingredientes["gambas"] = new tarifa_ingrediente ("gambas", 0.3, 0.45);
$_ingredientes["pepperoni"] = new tarifa_ingrediente ("pepperoni", 0.15, 0.3);
$_ingredientes["pimientos"] = new tarifa_ingrediente ("pimientos", 0.2, 0.25);
$_ingredientes["jalapenos"] = new tarifa_ingrediente ("japalenos", 0.15, 0.25);
$_ingredientes["pollo marinado"] = new tarifa_ingrediente ("pollo marinado", 0.35, 0.45);
$_ingredientes["queso cheddar"] = new tarifa_ingrediente ("queso cheddar", 0.25, 0.5);
$_ingredientes["queso provolone"] = new tarifa_ingrediente ("queso provolone",0.3, 0.45);
$_ingredientes["queso suizo"] = new tarifa_ingrediente ("queso suizo", 0.4, 0.65);
$_ingredientes["salchicha"] = new tarifa_ingrediente ("salchichas", 0.25, 0.5);
$_ingredientes["tomate natural"] = new tarifa_ingrediente ("tomate natural", 0.15, 0.25);
$_ingredientes["jamon york"] = new tarifa_ingrediente ("jamon york", 0.15, 0.25);