<?php
require_once 'clases/pizza.class.php';
require_once 'clases/ingrediente.class.php';
session_start();
/** @var pizza $pizza */
$pizza = $_SESSION["pizza"];
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pague su pizza</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<main>
    <div class="container">
        <h1>PIZZA</h1>
        <table class="table table-bordered table-sm">
            <thead>
            <tr>
                <th>NOMBRE</th>
                <th>TIPO</th>
                <th>PRECIO</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo $pizza->getNombre(); ?></td>
                <td><?php echo $pizza->getTipo(); ?></td>
                <td><?php echo number_format($pizza->getPrecio(), 2); ?></td>
            </tr>
            </tbody>
        </table>
        <h2>INGREDIENTES</h2>
        <table class="table table-bordered table-sm">
            <thead>
            <tr>
                <th>INGREDIENTE</th>
                <th>CANTIDAD</th>
                <th>PRECIO</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($pizza->getIngredientes() as $ingredientePizza) :?>
                <tr>
                    <td><?php echo $ingredientePizza->getNombre(); ?></td>
                    <td><?php echo $ingredientePizza->getCantidad(); ?></td>
                    <td><?php echo number_format($ingredientePizza->getPrecio(), 2); ?></td>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>

        <h1>PRECIO <?php echo number_format($pizza->calcularPrecio(), 2); ?> Euros</h1>
    </div>
</main>
</body>
</html>
