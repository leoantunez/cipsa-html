<?php

class tarifa_pizza{
    private $nombre;
    private $mediana;
    private $normal;
    private $familiar;

    public function __construct($nombre, $mediana, $normal, $familiar)
    {
        $this->nombre = $nombre;
        $this->mediana = $mediana;
        $this->normal = $normal;
        $this->familiar = $familiar;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     * @return tarifa_pizza
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getMediana()
    {
        return $this->mediana;
    }

    /**
     * @param mixed $mediana
     * @return tarifa_pizza
     */
    public function setMediana($mediana)
    {
        $this->mediana = $mediana;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getNormal()
    {
        return $this->normal;
    }

    /**
     * @param mixed $normal
     * @return tarifa_pizza
     */
    public function setNormal($normal)
    {
        $this->normal = $normal;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getFamiliar()
    {
        return $this->familiar;
    }

    /**
     * @param mixed $familiar
     * @return tarifa_pizza
     */
    public function setFamiliar($familiar)
    {
        $this->familiar = $familiar;
        return $this;
    }




}
