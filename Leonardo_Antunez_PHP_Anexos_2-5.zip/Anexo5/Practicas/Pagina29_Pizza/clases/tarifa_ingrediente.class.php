<?php

class tarifa_ingrediente{
    private $nombre;
    private $simple;
    private $doble;

    /**
     * @param $nombre
     * @param $simple
     * @param $doble
     */
    public function __construct($nombre, $simple, $doble)
    {
        $this->nombre = $nombre;
        $this->simple = $simple;
        $this->doble = $doble;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     * @return tarifa_ingrediente
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getSimple()
    {
        return $this->simple;
    }

    /**
     * @param mixed $simple
     * @return tarifa_ingrediente
     */
    public function setSimple($simple)
    {
        $this->simple = $simple;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getDoble()
    {
        return $this->doble;
    }

    /**
     * @param mixed $doble
     * @return tarifa_ingrediente
     */
    public function setDoble($doble)
    {
        $this->doble = $doble;
        return $this;
    }




}