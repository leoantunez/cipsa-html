<?php

class pizza
{
    private $nombre;
    private $tipo;
    private $precio;
    private $ingredientes;

    /**
     * @param $nombre
     * @param $tipo
     * @param $precio
     */
    public function __construct($nombre, $tipo, $precio)
    {
        $this->nombre = $nombre;
        $this->tipo = $tipo;
        $this->precio = $precio;
        $this->ingredientes = [];
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     * @return pizza
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * @param mixed $tipo
     * @return pizza
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrecio()
    {
        return $this->precio;
    }

    /**
     * @param mixed $precio
     * @return pizza
     */
    public function setPrecio($precio)
    {
        $this->precio = $precio;
        return $this;
    }

    /**
     * @return array
     */
    public function getIngredientes(): array
    {
        return $this->ingredientes;
    }

    /**
     * @param array $ingredientes
     * @return pizza
     */
    public function setIngredientes(array $ingredientes): pizza
    {
        $this->ingredientes = $ingredientes;
        return $this;
    }

    public function calcularPrecio()
    {
        $precio = $this->precio;
        foreach ($this->ingredientes as $ingrediente) {
            $precio += $ingrediente->getPrecio();
        }
        return $precio;
    }

    public function agregarIngrediente($ingrediente)
    {
        $this->ingredientes[] = $ingrediente;
    }

}