<?php

class ingrediente{
    private $nombre;
    private $cantidad;
    private $precio;

    /**
     * @param $nombre
     * @param $cantidad
     * @param $precio
     */
    public function __construct($nombre, $cantidad, $precio)
    {
        $this->nombre = $nombre;
        $this->cantidad = $cantidad;
        $this->precio = $precio;
    }

    /**
     * @return mixed
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed $nombre
     * @return ingrediente
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * @param mixed $cantidad
     * @return ingrediente
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrecio()
    {
        return $this->precio;
    }

    /**
     * @param mixed $precio
     * @return ingrediente
     */
    public function setPrecio($precio)
    {
        $this->precio = $precio;
        return $this;
    }




}