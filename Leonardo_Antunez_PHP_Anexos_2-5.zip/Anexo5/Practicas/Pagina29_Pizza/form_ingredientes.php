<?php
require_once 'modelo/datos.php';
require_once 'clases/pizza.class.php';
require_once 'clases/ingrediente.class.php';
session_start();
if (!array_key_exists("pizza", $_SESSION) || !$_SESSION["pizza"]) {
    if (!$_SESSION['pizza'] instanceof pizza){
        if (!isset($_POST['pizza']) || !isset($_POST['tamano'])) {
            header('HTTP/1.0 400 Bad Request');
            echo '<h1>Datos incorrectos. Intente de nuevo</h1>';
            exit;
        }
    }
    $precio = 0;
    switch ($_POST['tamano']) {
        case 'mediana':
            $precio = $_pizzas[$_POST['pizza']]->getMediana();
            break;
        case 'normal':
            $precio = $_pizzas[$_POST['pizza']]->getNormal();
            break;
        case 'familiar':
            $precio = $_pizzas[$_POST['pizza']]->getFamiliar();
            break;
    }
    $pizza = new pizza($_POST['pizza'], $_POST['tamano'], $precio);
    $_SESSION["pizza"] = $pizza;
} else {
    /** @var pizza $pizza */
    $pizza = $_SESSION["pizza"];
    if (isset($_POST['ingrediente']) && isset($_POST['cantidad'])) {
        $precioIngrediente = 0;
        switch ($_POST['cantidad']) {
            case 'simple':
                $precioIngrediente = $_ingredientes[$_POST['ingrediente']]->getSimple();
                break;
            case 'doble':
                $precioIngrediente = $_ingredientes[$_POST['ingrediente']]->getDoble();
                break;
        }
        $ingrediente = new ingrediente($_POST['ingrediente'], $_POST['cantidad'], $precioIngrediente);
        $pizza->agregarIngrediente($ingrediente);
        $_SESSION["pizza"] = $pizza;
    }

}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Selección de ingredientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<main>
    <div class="container">
        <h1>INGREDIENTES</h1>
        <h3>PIZZA <?php echo $pizza->getNombre() ?> <?php echo $pizza->getTipo() ?></h3>
        <form action="form_ingredientes.php" method="post">
            <div class="row">
                <div class="col-lg-4">
                    <div class="form-group">
                        <select required name="ingrediente" id="ingrediente" class="form-control">
                            <?php foreach ($_ingredientes as $nombreIngrediente => $ingrediente) :?>
                                <option value="<?php echo $nombreIngrediente; ?>"><?php echo $nombreIngrediente; ?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="form-group">
                        <label for="simple">
                            <input required type="radio" name="cantidad" value="simple" id="simple">
                            Simple
                        </label>
                        <label for="doble">
                            <input required type="radio" name="cantidad" value="doble" id="doble">
                            Doble
                        </label>
                    </div>
                </div>
                <div class="col-lg-3">
                    <button type="submit" class="btn w-50 btn-primary">ingrediente</button>
                </div>
            </div>
        </form>

        <h3 class="mt-3">INGREDIENTES SELECCIONADOS</h3>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>INGREDIENTE</th>
                <th>CANTIDAD</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($pizza->getIngredientes() as $ingredientePizza) :?>
                <tr>
                    <td><?php echo $ingredientePizza->getNombre(); ?></td>
                    <td><?php echo $ingredientePizza->getCantidad(); ?></td>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>

        <a class="btn btn-sm btn-outline-danger mr-2" href="form_pizza.php?descartar">DESCARTAR</a>
        <a class="btn btn-sm btn-outline-primary" href="form_pago.php">PAGAR</a>
    </div>
</main>
</body>
</html>
