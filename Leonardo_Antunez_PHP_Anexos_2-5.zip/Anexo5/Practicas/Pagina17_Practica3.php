<?php

class persona{
    private $nombre;
    private $edad;

    public function __construct($nombre, $edad)
    {
        $this->nombre = $nombre;
        $this->edad = $edad;
    }

    public function Saludar(){
        echo "Hola {$this->nombre}";
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function setNombre($nombre): void
    {
        $this->nombre = $nombre;
    }

    public function getEdad()
    {
        return $this->edad;
    }

    public function setEdad($edad): void
    {
        $this->edad = $edad;
    }

    public function cumpleAnnos()
    {
        $this->edad = $this->edad + 1;
    }
}


$persona = new persona("Leonardo", 34);
$persona->cumpleAnnos();
